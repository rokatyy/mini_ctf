def check(string):
	s="cj`g|i34iem8{i?<\x82\x8b"
	f=False
	for i in range(len(string)):
		if chr(ord(string[i])+i-int(1337//337))==s[i]:f=True
	return f
if __name__=="__main__":
	s=input("Enter your pass: ")
	if check(s): print("Valid!")
	else: print("Invalid")